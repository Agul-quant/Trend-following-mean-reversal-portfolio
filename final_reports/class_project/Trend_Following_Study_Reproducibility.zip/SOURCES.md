# Sources and relevance

Verified against primary author, institutional or university-repository pages on
October 19, 2026. These citations provide methodology context, not market input
rows or external validation of this project's performance. No paper or course
brief is redistributed in the supplement.

1. **Moskowitz, T. J., Ooi, Y. H., and Pedersen, L. H. (2012). “Time Series
   Momentum.” Journal of Financial Economics, 104(2), 228–250.**
   [AQR research page](https://www.aqr.com/Insights/Research/Journal-Article/Time-Series-Momentum).
   The paper motivates trend persistence based on an instrument's own history
   across diverse futures/forward markets. The present daily-indicator ETF
   long/cash strategies are a different implementation, not a replication of
   the paper's contracts, horizons, leverage or reported returns. This source
   does not establish the efficacy of the project's mean-reversion rules.

2. **Sharpe, W. F. (1994). “The Sharpe Ratio.” The Journal of Portfolio
   Management, Fall 1994.**
   [Author-hosted Stanford text](https://web.stanford.edu/~wfsharpe/art/sr/sr.htm).
   Supports using the mean and variability of differential returns. This project
   subtracts the actual matched cash path before both the mean and sample
   standard deviation; it does not divide CAGR by volatility or interpret
   “cash-excess” as outperformance versus buy-and-hold.

3. **Lo, A. W. (2002). “The Statistics of Sharpe Ratios.” Financial Analysts
   Journal, 58(4), 36–52.**
   [MIT author publication entry](https://alo.mit.edu/publications/page/18/),
   [MIT research page](https://alo.mit.edu/research-page/the-statistics-of-sharpe-ratios/).
   Explains estimation uncertainty and the importance of serial dependence and
   time aggregation for Sharpe interpretation. The project's square-root-252
   convention is descriptive, not a dependence-robust significance claim. No
   HAC standard errors, inferential confidence intervals or future-Sharpe
   guarantees are supplied.

4. **Bailey, D. H., Borwein, J., López de Prado, M., and Zhu, Q. J. (2017).
   “The Probability of Backtest Overfitting.” Journal of Computational Finance.
   DOI: 10.21314/JCF.2016.322.**
   [Western Michigan University repository](https://scholarworks.wmich.edu/math_pubs/42/),
   [University of California repository record](https://escholarship.org/uc/item/4w1110bb).
   Provides a framework for selection-induced backtest overfitting and discusses
   combinatorially symmetric cross-validation. It motivates the project's
   caution about many configurations, post-OOS filtering and portfolio fitting.
   The supplement does **not** claim to have computed a PBO or CSCV estimate.

## Project-specific evidence

The numerical source of the report is the completed saved ETF account studies
and their verified aggregate exports, not the papers above. The supplement's
`SUPPLEMENT_MANIFEST.json` binds included files by relative path and SHA256.
`reports/four_portfolios_three_periods/provenance.json` summarizes the earlier
private saved-path review without publishing input locators or freezes. Full
historical numerical reproduction requires privately supplied, matching-vintage
saved account bundles; aggregate tables and cited academic papers are not a
substitute for those inputs.
