# Trend Following Study — reproducibility supplement

This supplement accompanies the separate class-project report. It studies four
**unchanged initial allocations** of six long/cash ETF strategy sleeves: GDX,
FXI, QQQ, UNG, FDN and BND. The standalone maximum-CAGR / 100%-GDX portfolio is
excluded. GDX remains a component of the four retained allocations.

## What is reproducible here

The portable code reproduces portfolio aggregation, cash-excess Sharpe, CAGR,
daily drawdown, volatility, daily capital-share diagnostics, correlations and
single-/six-passive-ETF regression attribution **from independently supplied saved
account paths**. It does not download prices or reproduce the original daily
indicator / half-hour execution engine from raw market data. Full historical
trade reconstruction and data reconciliation require private source evidence not
included in this supplement. Aggregate CSVs alone cannot reconstruct daily paths.

The supplied historical aggregates cover three separately initialized periods:

| Parent-account period | Scored dates | Saved daily observations |
|---|---|---:|
| Development | 2017-01-01–2020-12-31 | 1,007 |
| Validation | 2021-01-01–2023-12-31 | 753 |
| Historical OOS | 2024-01-01–2026-10-15 | 700 |

Every period starts afresh with $1,000; no holdings, orders, confirmation streaks
or wealth carry between stages. The same full-precision initial allocations are
used throughout. Costs are 1-bp commission plus 1/3/10/25-bp one-way slippage,
each way. Saved paths already include cash, corporate actions, reinvestment,
trading costs and paid terminal liquidation; the portable layer does not charge
them again. Cash is 3% nominal ACT/365 event-compounded, not a 3% APY shortcut.

## Contents

- `configs/`: the four exact allocations, six exact strategy definitions and
  research conventions. Original five-portfolio historical files are not replaced.
- `src/trend_portfolio/`, `scripts/`, `tests/`: portable analytics and generated
  synthetic fixtures. Synthetic tests are not market-performance evidence.
- `reports/four_portfolios_three_periods/`: 48 portfolio outcomes, 24 matched
  controls, 48 cap diagnostics, three stage-clock summaries, narrative and JSON.
- `results/attribution/`: 48 QQQ single-factor and 48 six-passive-factor fits,
  12 factor-diagnostic rows and 72 passive self-regression controls.
- `results/`: public six-strategy, matched buy-and-hold and correlation summaries.
- `figures/`: three baseline combined equity/drawdown panels plus the historical
  OOS active-strategy correlation heatmap, raster PNG only.
- `docs/`: saved-input schema and three-period reporting guidance.
- `SOURCES.md`: verified primary academic references and their limited relevance.
- `PROTOCOL_NOTES.md`: inherited OOS-specific metadata versus independent stage clocks.
- `REQUIREMENT_COVERAGE.md`: seven-section course-project coverage and explicit
  unimplemented extensions. No copy of the original course brief is redistributed.
- `SUPPLEMENT_MANIFEST.json`: relative archive paths, file sizes and SHA256 hashes.

No raw prices, numerical daily market/account arrays, private source paths,
authorizations, input seals, credentials, study freezes or original course brief
are included. Figures visualize approved saved paths but embed no numerical
curves or private locators in PNG metadata.

## Install and test

Python 3.12 was used for the delivered figures and calculations (tested runtime:
NumPy 2.4.6, SciPy 1.15.3, Matplotlib 3.10.8, pytest 9.0.3).

```bash
python -m pip install -r requirements.txt
python -m pip install -e . --no-deps
python -m pytest -q tests presentation/test_calculate_attribution.py
```

The bundled tests generate their own synthetic inputs. They do not require private
historical account data. Optional generic optimizer functions are retained as
research utilities, but are **not used to regenerate or replace** these four
saved allocations. No new optimization or trading is needed for this project.

## Recompute aggregate tables with private saved inputs

Provide the exact private standard NPZ schema in `docs/input_schema.md` and the
three-stage manifest in `docs/periods.md`. The manifest's initial account-open
clocks must be the true first-session opens; actual final valuation clocks
independently determine each stage's ACT/365 years.

```bash
python scripts/report_periods.py \
  --manifest /outside/checkout/private_periods_manifest.json \
  --portfolios configs/four_portfolios.json \
  --output-dir outputs/new_three_period_attempt
```

This writes aggregate CSV/JSON only. The output directory must not exist. The
standard six-symbol and four-cost axes are checked. Undefined cash-excess Sharpe
is JSON `null` / an empty CSV field, never silently zero.

For attribution or document-sized figures, create a PRIVATE input seal
`{"files": {"ABSOLUTE_INPUT_PATH": "SHA256", ...}}` binding the manifest,
configuration and all three NPZ bundles; the figure seal must also bind the
correlation CSV. This seal contains private locators and must not be published.

```bash
python presentation/calculate_attribution.py \
  --manifest /outside/checkout/private_periods_manifest.json \
  --portfolios configs/four_portfolios.json \
  --input-seal /outside/checkout/private_input_seal.json \
  --output outputs/new_attribution_attempt

python presentation/build_figures.py \
  --manifest /outside/checkout/private_periods_manifest.json \
  --portfolios configs/four_portfolios.json \
  --correlations results/strategy_correlation_matrices_all_costs.csv \
  --input-seal /outside/checkout/private_input_seal.json \
  --output-dir outputs/new_figure_attempt
```

An input seal is an integrity check, not proof of economic correctness or a new
stage release. The private provider must certify calendars, price units,
corporate actions, execution timing, stage resets and cost matching. Never
substitute fresh adjustment factors for legacy adjusted bars or infer missing
account observations from aggregate statistics.

## Interpretation limits

Selection, ETF pruning and allocation fitting used already examined historical
outcomes, including the historical OOS interval. Applying the same weights to
older periods is a retrospective diagnostic—not newly untouched portfolio
validation. High fitted-period Sharpe or positive alpha does not establish skill,
causality or future returns. The square-root-252 Sharpe is a descriptive convention;
no serial-dependence-adjusted inference, significance test or PBO estimate is
claimed. See `SOURCES.md`.

The daily-cap weights are not a daily rebalancing policy. Their validation-period
maximum sleeve capital share is about 35.18% at baseline, breaching one third on
41 daily valuations. This breach is reported, not repaired by refitting or free
trades. Caps concern strategy-account capital including idle cash, not continuous
ETF exposure, intraday weights or risk contribution. Passive QQQ is a matched
control, not the active QQQ strategy. Joint betas are conditional sensitivities,
not weights; a negative coefficient does not create a short position. Annual
alpha is 252 times the daily intercept, arithmetic, not CAGR.
