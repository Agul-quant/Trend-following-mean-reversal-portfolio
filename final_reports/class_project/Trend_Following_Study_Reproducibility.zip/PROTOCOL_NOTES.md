# Reading the inherited protocol configuration

`configs/research_protocol.json` preserves the original six-sleeve portfolio
snapshot's core conventions without rewriting historical records. Its top-level
`ACT365_elapsed_years` and `daily_cap_scope` references to 700 observations are
**historical-OOS-specific** metadata, not development or validation clocks.

For the three-period comparison, use `reports/four_portfolios_three_periods/
stage_summaries.csv` and the actual final valuation minus initial account-open
clock computed by `scripts/report_periods.py`:

- Development: 3.9953767123287673 ACT/365 years; 1,007 observations.
- Validation: 2.984417808219178 ACT/365 years; 753 observations.
- Historical OOS: 2.787043378995434 ACT/365 years; 700 observations.

The four saved initial allocations are specified only by
`configs/four_portfolios.json`. No standalone 100%-GDX allocation is included in
this project. GDX remains in the six strategy definitions. The inherited generic
code's optional maximum-CAGR helper does not introduce that excluded allocation
or authorize a new fit.

The historical daily-cap allocation was fitted on the examined OOS period and
is applied backward unchanged here. A validation-period cap breach is a result
to report, not an error to repair. The descriptive daily diagnostics do not
change any holdings, charge new costs or promise future enforcement.
