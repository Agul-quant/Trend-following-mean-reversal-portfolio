"""No private data: verify the explicit class-project supplement and aggregates."""
import csv
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
IDS = {"daily_capped_max_sharpe", "initial_capped_max_sharpe", "uncapped_max_sharpe", "equal_initial"}
STAGES = {"development", "validation", "historical_OOS"}


def rows(relative):
    with (ROOT / relative).open(newline="") as stream:
        return list(csv.DictReader(stream))


def test_all_packaged_files_match_manifest_and_no_raw_inputs():
    manifest = json.loads((ROOT / "SUPPLEMENT_MANIFEST.json").read_text())
    assert not manifest["daily_market_or_account_arrays_included"]
    assert not manifest["private_source_locators_included"]
    paths = set()
    for record in manifest["files"]:
        relative = Path(record["path"])
        assert not relative.is_absolute() and ".." not in relative.parts
        assert relative.suffix.lower() not in {".npz", ".npy", ".parquet", ".svg", ".docx", ".pdf"}
        assert ".cache" not in relative.parts and "private" not in relative.parts
        content = (ROOT / relative).read_bytes()
        assert len(content) == record["bytes"]
        assert hashlib.sha256(content).hexdigest() == record["sha256"]
        assert record["path"] not in paths
        paths.add(record["path"])


def test_four_allocations_and_exact_stage_cost_outcomes():
    config = json.loads((ROOT / "configs/four_portfolios.json").read_text())
    assert {record["id"] for record in config["portfolios"]} == IDS
    assert set(config["symbols"]) == {"GDX", "FXI", "QQQ", "UNG", "FDN", "BND"}
    metrics = rows("reports/four_portfolios_three_periods/portfolio_rows.csv")
    assert len(metrics) == 48
    keys = {(row["stage"], row["portfolio_id"], float(row["slippage_bps_each_way"])) for row in metrics}
    assert keys == {(stage, portfolio, cost) for stage in STAGES for portfolio in IDS for cost in [1, 3, 10, 25]}
    controls = rows("reports/four_portfolios_three_periods/control_rows.csv")
    assert len(controls) == 24
    assert {row["control_id"] for row in controls} == {"QQQ_buy_and_hold", "matched_cash"}
    assert len(rows("reports/four_portfolios_three_periods/cap_rows.csv")) == 48
    clocks = rows("reports/four_portfolios_three_periods/stage_summaries.csv")
    assert {row["stage"] for row in clocks} == STAGES
    assert {int(row["observations"]) for row in clocks} == {1007, 753, 700}


def test_attribution_counts_and_portfolio_scope():
    for name in ("QQQ_single_factor_all_periods_all_costs.csv", "six_passive_factor_all_periods_all_costs.csv"):
        table = rows("results/attribution/" + name)
        assert len(table) == 48
        assert {row["portfolio_id"] for row in table} == IDS
        assert {row["stage"] for row in table} == STAGES
    assert len(rows("results/attribution/factor_diagnostics_all_periods_all_costs.csv")) == 12
    assert len(rows("results/attribution/passive_factor_self_controls.csv")) == 72


def test_figures_are_only_raster_with_generic_metadata():
    from PIL import Image
    figures = list((ROOT / "figures").glob("*.png"))
    assert {p.name for p in figures} == {"development_baseline.png", "validation_baseline.png", "historical_OOS_baseline.png", "oos_strategy_correlations.png"}
    for figure in figures:
        with Image.open(figure) as image:
            assert image.width == 1300
            assert set(image.info) <= {"Software", "dpi"}
            assert image.info["Software"] == "Trend Following Study"
