"""Closed mathematical fixtures: no original account inputs read by these tests."""
import importlib.util
from pathlib import Path

import numpy as np
import pytest

spec = importlib.util.spec_from_file_location("closed_attribution", Path(__file__).with_name("calculate_attribution.py"))
calc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(calc)


def test_known_single_factor_and_arithmetic_annual_alpha():
    x = np.linspace(-.02, .03, 101)
    result = calc.fit_centered(.0004 + 1.7 * x, x)
    assert result["alpha_daily"] == pytest.approx(.0004, abs=1e-14)
    assert result["alpha_annual_arithmetic"] == pytest.approx(.1008, abs=1e-13)
    assert result["alpha_annual_arithmetic"] != pytest.approx((1.0004 ** 252) - 1)
    assert result["betas"] == pytest.approx([1.7])
    assert result["r_squared"] == pytest.approx(1)


def test_known_six_factor_coefficients_and_self_control():
    rng = np.random.default_rng(1901001)
    x = rng.normal(0, .01, (600, 6))
    beta = np.array([.2, -.5, .03, 1.1, .8, -.1])
    result = calc.fit_centered(.00012 + x @ beta, x)
    assert result["betas"] == pytest.approx(beta, abs=1e-12)
    assert result["alpha_daily"] == pytest.approx(.00012, abs=1e-14)
    for i in range(6):
        self_fit = calc.fit_centered(x[:, i], x)
        assert self_fit["betas"] == pytest.approx(np.eye(6)[i], abs=1e-12)
        assert self_fit["alpha_daily"] == pytest.approx(0, abs=1e-14)
        assert self_fit["r_squared"] == pytest.approx(1)


def test_cash_subtracted_exactly_once_from_portfolio_and_passive_control():
    cash = np.array([.001, .0001, .0002, .0015, .0001])
    passive_excess = np.array([-.02, .01, .03, -.005, .015])
    portfolio_returns = cash + .0003 + .8 * passive_excess
    result = calc.fit_centered(portfolio_returns - cash, (cash + passive_excess) - cash)
    assert result["betas"] == pytest.approx([.8])
    assert result["alpha_daily"] == pytest.approx(.0003)


def test_static_initial_wealth_includes_first_and_terminal_return_without_rebalance():
    equity = np.array([[.999, 1.0], [1.2, .8], [1.1, .79]])
    weights = [.4, .6]
    got = calc.fixed_wealth_returns(equity, weights)
    wealth = equity @ weights
    np.testing.assert_allclose(got, wealth / np.r_[1., wealth[:-1]] - 1)
    assert got[0] == pytest.approx(-.0004)
    assert got[-1] == pytest.approx(wealth[-1] / wealth[-2] - 1)
    assert not np.isclose(got[-1], .4 * (1.1 / 1.2 - 1) + .6 * (.79 / .8 - 1))


@pytest.mark.parametrize("bad", [np.nan, np.inf, -np.inf])
def test_nonfinite_values_are_not_silently_dropped(bad):
    x = np.arange(10, dtype=float)
    y = x.copy()
    y[3] = bad
    with pytest.raises(ValueError):
        calc.fit_centered(y, x)


def test_collinearity_and_constant_dependent_variable_rejected():
    x = np.arange(10, dtype=float)
    with pytest.raises(ValueError, match="linearly independent"):
        calc.fit_centered(x, np.column_stack([x, 2 * x]))
    with pytest.raises(ValueError, match="variance"):
        calc.fit_centered(np.ones(10), x)


def test_aware_clock_equivalence_and_duplicate_rejection():
    np.testing.assert_array_equal(calc.clock_ns(["2024-01-02 22:00:00+00:00"]),
                                  calc.clock_ns(["2024-01-02T17:00:00-05:00"]))
    with pytest.raises(ValueError):
        calc.clock_ns(["2024-01-02T17:00:00"])
    with pytest.raises(ValueError):
        calc.clock_ns(["2024-01-02T22:00:00Z"] * 2)
