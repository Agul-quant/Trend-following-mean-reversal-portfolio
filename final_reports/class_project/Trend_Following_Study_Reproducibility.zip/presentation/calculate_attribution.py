"""Portable fixed saved-input attribution; no strategy/account/optimizer imports.

Inputs must be privately supplied and independently reconciled. All input locators
stay outside outputs; this script emits aggregate coefficients and audit hashes.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from datetime import datetime
from pathlib import Path

import numpy as np

SYMBOLS = ["GDX", "FXI", "QQQ", "UNG", "FDN", "BND"]
COSTS = [1, 3, 10, 25]


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path):
    value = json.loads(Path(path).read_text())
    if "payload" in value:
        payload = value["payload"]
        assert value["payload_sha256"] == hashlib.sha256(
            json.dumps(payload, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
        ).hexdigest()
        return payload
    return value


def fit_centered(y, factors):
    """OLS with intercept, implemented through centered covariance equations."""
    y, factors = np.asarray(y, float), np.asarray(factors, float)
    if factors.ndim == 1:
        factors = factors[:, None]
    if y.ndim != 1 or factors.ndim != 2 or factors.shape[0] != len(y):
        raise ValueError("Regression dimensions disagree")
    n, k = factors.shape
    if n <= k + 1 or not np.isfinite(y).all() or not np.isfinite(factors).all():
        raise ValueError("Insufficient or nonfinite regression observations")
    xbar, ybar = np.mean(factors, axis=0), float(np.mean(y))
    centered_x, centered_y = factors - xbar, y - ybar
    if np.linalg.matrix_rank(centered_x) != k:
        raise ValueError("The passive factor columns are not linearly independent")
    covariance = centered_x.T @ centered_x / (n - 1)
    cross_covariance = centered_x.T @ centered_y / (n - 1)
    beta = np.linalg.solve(covariance, cross_covariance)
    alpha_daily = ybar - float(xbar @ beta)
    residual = y - (alpha_daily + factors @ beta)
    tss = float(centered_y @ centered_y)
    if tss == 0:
        raise ValueError("Dependent return variance is zero")
    r2 = 1 - float(residual @ residual) / tss
    return {
        "alpha_daily": alpha_daily,
        "alpha_annual_arithmetic": 252 * alpha_daily,
        "betas": beta.tolist(),
        "r_squared": r2,
        "adjusted_r_squared": 1 - (1 - r2) * (n - 1) / (n - k - 1),
        "observations": n,
        "factor_count": k,
        "residual_annualized_volatility": float(np.std(residual, ddof=1)) * math.sqrt(252),
    }


def fixed_wealth_returns(normalized_equity, initial_weights):
    eq, weights = np.asarray(normalized_equity, float), np.asarray(initial_weights, float)
    if eq.ndim != 2 or eq.shape[1] != len(weights) or not np.isfinite(eq).all() or np.any(eq <= 0):
        raise ValueError("Invalid normalized saved equity")
    if np.min(weights) < 0 or abs(float(np.sum(weights)) - 1) > 1e-12:
        raise ValueError("Not a long-only unlevered initial allocation")
    wealth = sum(eq[:, i] * weights[i] for i in range(len(weights)))
    return wealth / np.r_[1.0, wealth[:-1]] - 1


def clock_ns(values):
    parsed = [datetime.fromisoformat(str(x).replace("Z", "+00:00")) for x in values]
    if any(x.tzinfo is None for x in parsed):
        raise ValueError("Timezone-aware saved clocks required")
    result = np.array([round(x.timestamp() * 10**9) for x in parsed], dtype=np.int64)
    if not np.all(np.diff(result) > 0):
        raise ValueError("Saved clocks must be unique and increasing")
    return result


def write_csv(path, rows):
    assert rows
    fields = list(rows[0])
    with path.open("x", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            assert list(row) == fields
            writer.writerow(row)


def calculate(output, manifest_path, config_path, release_path):
    if output.exists():
        raise ValueError("Preserve completed/failed attempts; choose a new output directory")
    output.mkdir(parents=True)
    release = read_json(release_path)
    if not isinstance(release.get("files"), dict):
        raise ValueError("Private input seal requires files path-to-SHA256 mapping")
    for required in (manifest_path, config_path):
        if str(required.resolve()) not in release["files"]:
            raise ValueError("Manifest and configuration must be sealed before numerical reads")
    for name, digest in release["files"].items():
        assert sha(name) == digest, name
    config = read_json(config_path)
    assert config["symbols"] == SYMBOLS and len(config["portfolios"]) == 4
    assert all(p["id"] != "max_cagr_100pct_gdx" for p in config["portfolios"])
    manifest = read_json(manifest_path)
    single, joint, diagnostics, self_checks, clocks = [], [], [], [], []
    for stage, count in [("development", 1007), ("validation", 753), ("historical_OOS", 700)]:
        stage_spec = manifest["stages"][stage]
        input_path = Path(stage_spec["input"])
        if not input_path.is_absolute():
            input_path = manifest_path.parent / input_path
        input_path = input_path.resolve()
        assert str(input_path) in release["files"]
        with np.load(input_path, allow_pickle=False) as bundle:
            assert bundle["symbols"].tolist() == SYMBOLS
            assert bundle["slippage_bps"].tolist() == COSTS
            equity = bundle["sleeve_normalized_equity"].copy()
            passive = bundle["buy_and_hold_returns"].copy()
            cash = bundle["cash_returns"].copy()
            times = clock_ns(bundle["timestamps"])
        assert equity.shape == passive.shape == (4, count, 6) and cash.shape == (count,)
        assert len(times) == count and np.isfinite(passive).all() and np.isfinite(cash).all()
        assert np.all(passive > -1)
        initial = datetime.fromisoformat(stage_spec["initial_timestamp"])
        assert initial.tzinfo is not None and round(initial.timestamp() * 10**9) < times[0]
        clocks.append({"stage": stage, "observations": count, "input_sha256": sha(input_path),
                       "initial_timestamp": initial.isoformat(),
                       "clock_UTC_nanosecond_sha256": hashlib.sha256(times.tobytes()).hexdigest(),
                       "cash_reference_sha256": hashlib.sha256(cash.tobytes()).hexdigest()})
        for c, cost in enumerate(COSTS):
            x = passive[c] - cash[:, None]
            xcentered = x - np.mean(x, axis=0)
            standard = xcentered / np.std(x, axis=0, ddof=1)
            correlation = standard.T @ standard / (count - 1)
            vif = np.diag(np.linalg.inv(correlation))
            diagnostics.append({"stage": stage, "slippage_bps_each_way": cost,
                                "commission_bps_each_way": 1, "observations": count,
                                "regression_design_rank_including_intercept": int(np.linalg.matrix_rank(np.column_stack([np.ones(count), x]))),
                                "standardized_factor_condition_number": float(np.linalg.cond(standard)),
                                **{"VIF_" + symbol: float(vif[i]) for i, symbol in enumerate(SYMBOLS)}})
            for i, symbol in enumerate(SYMBOLS):
                fitted = fit_centered(x[:, i], x)
                target = np.eye(6)[i]
                assert np.allclose(fitted["betas"], target, rtol=0, atol=2e-12)
                assert abs(fitted["alpha_annual_arithmetic"]) < 2e-12
                assert abs(fitted["r_squared"] - 1) < 2e-12
                self_checks.append({"stage": stage, "slippage_bps_each_way": cost, "passive_factor": symbol,
                                    "max_absolute_beta_error": float(np.max(np.abs(np.array(fitted["betas"]) - target))),
                                    "absolute_annual_alpha": abs(fitted["alpha_annual_arithmetic"]),
                                    "absolute_r_squared_error": abs(fitted["r_squared"] - 1)})
            for p in config["portfolios"]:
                w = p["initial_weights"]
                weights = [w[symbol] for symbol in SYMBOLS] if isinstance(w, dict) else w
                returns = fixed_wealth_returns(equity[c], weights)
                y = returns - cash
                common = {"stage": stage, "portfolio_id": p["id"], "slippage_bps_each_way": cost,
                          "commission_bps_each_way": 1}
                qqq = fit_centered(y, x[:, SYMBOLS.index("QQQ")])
                single.append({**common, "alpha_daily": qqq["alpha_daily"],
                               "alpha_annual_arithmetic": qqq["alpha_annual_arithmetic"], "beta_QQQ": qqq["betas"][0],
                               "r_squared": qqq["r_squared"], "adjusted_r_squared": qqq["adjusted_r_squared"],
                               "observations": count, "residual_annualized_volatility": qqq["residual_annualized_volatility"]})
                fitted = fit_centered(y, x)
                joint.append({**common, "alpha_daily": fitted["alpha_daily"],
                              "alpha_annual_arithmetic": fitted["alpha_annual_arithmetic"],
                              **{"beta_" + symbol: fitted["betas"][i] for i, symbol in enumerate(SYMBOLS)},
                              "r_squared": fitted["r_squared"], "adjusted_r_squared": fitted["adjusted_r_squared"],
                              "observations": count, "residual_annualized_volatility": fitted["residual_annualized_volatility"]})
    assert len(single) == len(joint) == 48 and len(diagnostics) == 12 and len(self_checks) == 72
    for name, digest in release["files"].items():
        assert sha(name) == digest, name
    write_csv(output / "QQQ_single_factor_all_periods_all_costs.csv", single)
    write_csv(output / "six_passive_factor_all_periods_all_costs.csv", joint)
    write_csv(output / "factor_diagnostics_all_periods_all_costs.csv", diagnostics)
    write_csv(output / "passive_factor_self_controls.csv", self_checks)
    result = {"schema": "class_project_saved_four_portfolio_attribution_v1", "passed": True,
              "input_release_sha256": sha(release_path), "script_sha256": sha(__file__),
              "all_supplied_input_seal_bindings_unchanged_before_after": True,
              "four_fixed_portfolio_config_sha256": sha(config_path),
              "method": "Sample OLS with intercept via centered covariance solve. Daily portfolio and passive factor returns each subtract the exact same saved daily cash return once.",
              "annual_alpha": "252 times the fitted daily intercept, arithmetic, not CAGR and not compounded",
              "QQQ_benchmark": "Own-period, own-cost passive QQQ buy-and-hold, not the active QQQ strategy sleeve",
              "joint_factors": SYMBOLS, "joint_coefficients_are_not_allocation_weights": True,
              "inference": "Retrospective fitted-history attribution only; no p-values, significance, causal skill or untouched-OOS claim",
              "new_account_runs_optimization_downloads_original_writes": False,
              "stage_clocks": clocks, "QQQ_single_factor_rows": single, "six_passive_factor_rows": joint,
              "factor_diagnostic_rows": diagnostics, "passive_self_control_rows": self_checks,
              "files": {p.name: sha(p) for p in output.iterdir() if p.is_file()}}
    path = output / "attribution.json"
    path.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    print(json.dumps({"path": str(path), "sha256": sha(path), "single_rows": 48, "joint_rows": 48,
                      "self_controls": 72, "passed": True}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--portfolios", type=Path, required=True)
    parser.add_argument("--input-seal", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    arguments = parser.parse_args()
    calculate(arguments.output, arguments.manifest, arguments.portfolios, arguments.input_seal)
