#!/usr/bin/env python3
"""Build portrait-document raster figures from separately sealed private inputs.

Run from a portable project root containing src/trend_portfolio. Private input
locators remain private; only PNGs and aggregate verification metadata are saved.
No execution-engine evaluation, optimizer, daily-series export or new cost occurs.
"""
from __future__ import annotations

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys

import numpy as np


STAGES = ("development", "validation", "historical_OOS")
NAMES = {"development": "Development: 2017–2020", "validation": "Validation: 2021–2023",
         "historical_OOS": "Historical OOS: 2024–October 15, 2026"}
IDS = ("daily_capped_max_sharpe", "initial_capped_max_sharpe", "uncapped_max_sharpe", "equal_initial")
LABELS = ("Daily-cap max Sharpe", "Initial-cap max Sharpe", "Uncapped max Sharpe", "Equal initial allocation", "QQQ buy-and-hold")
COLORS = ("#0072B2", "#D08B00", "#009E73", "#875AA7", "#252525")
STYLES = ("-", (0, (5, 2)), (0, (2, 1.6)), "-.", (0, (5, 2.5)))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_seal(seal: Path, required: list[Path]) -> dict[str, str]:
    """Require a root-supplied private {files:{path:sha256}} release before arrays."""
    sealed = json.loads(seal.read_text())
    records = sealed.get("files", {})
    if not isinstance(records, dict):
        raise ValueError("input seal must contain files path->SHA256 mapping")
    normalized = {str(Path(path).resolve()): value for path, value in records.items()}
    for path in required:
        expected = normalized.get(str(path.resolve()))
        if not isinstance(expected, str) or len(expected) != 64 or digest(path) != expected:
            raise ValueError(f"required figure input is unsealed or changed: {path.name}")
    # Return only opaque hashes for private before/after checks, never output locators.
    return {str(path.resolve()): digest(path) for path in required}


def render_combined(data, stage: str, target: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.dates as mdates
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    from matplotlib.ticker import FuncFormatter, PercentFormatter, MaxNLocator

    if data.series_ids != (*IDS, "QQQ_buy_and_hold") or len(data.timestamps) != data.equity.shape[0]:
        raise ValueError("figure requires exactly four fixed saved portfolios plus passive QQQ")
    if target.exists():
        raise ValueError("figure already exists; preserve earlier attempts")
    with matplotlib.rc_context({"path.simplify": False, "font.family": "DejaVu Sans"}):
        figure = Figure(figsize=(6.5, 5.05), dpi=200, facecolor="white")
        FigureCanvasAgg(figure)
        equity_ax = figure.add_axes([.125, .49, .80, .285])
        drawdown_ax = figure.add_axes([.125, .17, .80, .235], sharex=equity_ax)
        for index in range(5):
            for axes, values in ((equity_ax, data.equity), (drawdown_ax, data.drawdown)):
                axes.plot(data.timestamps, values[:, index], color=COLORS[index], linestyle=STYLES[index],
                          linewidth=1.45 if index in (0, 4) else 1.2, label=LABELS[index],
                          zorder=5 if index in (0, 4) else 2, alpha=.97)
        # Common units/encodings; stage-specific limits are disclosed in the caption.
        for axes in (equity_ax, drawdown_ax):
            axes.grid(axis="y", color="#DCE1E5", linewidth=.5)
            axes.spines[["top", "right"]].set_visible(False)
            axes.spines[["left", "bottom"]].set_color("#7C8791")
            axes.tick_params(labelsize=9, length=3)
            axes.set_xlim(data.timestamps[0], data.timestamps[-1])
        equity_ax.set_ylim(bottom=0)
        equity_ax.set_ylabel("Value (USD)", fontsize=9.5, labelpad=4)
        equity_ax.yaxis.set_major_locator(MaxNLocator(nbins=4))
        equity_ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _: f"${value:,.0f}"))
        equity_ax.tick_params(labelbottom=False)
        drawdown_ax.set_ylim(min(-.01, float(data.drawdown.min()) * 1.08), 0)
        drawdown_ax.set_ylabel("Drawdown", fontsize=9.5, labelpad=4)
        drawdown_ax.yaxis.set_major_locator(MaxNLocator(nbins=4))
        drawdown_ax.yaxis.set_major_formatter(PercentFormatter(xmax=1, decimals=0))
        # Only three horizontal ticks keep exact endpoints legible at 6.5in print.
        middle_year = int((data.timestamps[0].year + data.timestamps[-1].year) / 2)
        middle = datetime(middle_year, 7, 1, tzinfo=timezone.utc)
        ticks = [data.timestamps[0]]
        if data.timestamps[0] < middle < data.timestamps[-1]:
            ticks.append(middle)
        ticks.append(data.timestamps[-1])
        drawdown_ax.set_xticks(ticks)
        drawdown_ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y-%m-%d", tz=timezone.utc))
        drawdown_ax.tick_params(axis="x", labelrotation=0, pad=5)
        figure.text(.125, .955, NAMES[stage], fontsize=12.5, weight="bold", color="#000000")
        figure.text(.125, .91, "$1,000 fresh start • 1-bp commission + 3-bp slippage each way", fontsize=9, color="#405263")
        handles, labels = equity_ax.get_legend_handles_labels()
        figure.legend(handles, labels, loc="center left", bbox_to_anchor=(.117, .835),
                      ncol=2, frameon=False, fontsize=8.5, handlelength=2.9,
                      columnspacing=1.35, labelspacing=.45, borderaxespad=0)
        figure.text(.125, .075, "Static initial allocation; no cross-sleeve rebalancing. Daily peaks include initial capital.", fontsize=8, color="#475765")
        figure.text(.125, .035, "Retrospective fitted allocations; not untouched portfolio OOS. Panels use stage-specific y scales.", fontsize=8, color="#475765")
        figure.savefig(target, format="png", dpi=200, facecolor="white",
                       metadata={"Software": "Trend Following Study"})
        figure.clear()


def render_correlation(source: Path, target: Path) -> None:
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib.figure import Figure
    from matplotlib.backends.backend_agg import FigureCanvasAgg
    symbols = ["GDX", "FXI", "QQQ", "UNG", "FDN", "BND"]
    with source.open(newline="") as stream:
        rows = [row for row in csv.DictReader(stream) if float(row["slippage_bps_each_way"]) == 3]
    if len(rows) != 6 or {row["symbol"] for row in rows} != set(symbols):
        raise ValueError("baseline strategy correlation needs exactly six symbols")
    by_symbol = {row["symbol"]: row for row in rows}
    matrix = np.array([[float(by_symbol[left][right]) for right in symbols] for left in symbols])
    if not np.isfinite(matrix).all() or not np.allclose(matrix, matrix.T, atol=1e-12) or not np.allclose(np.diag(matrix), 1, atol=1e-12):
        raise ValueError("invalid public correlation matrix")
    if target.exists():
        raise ValueError("correlation figure already exists")
    with matplotlib.rc_context({"font.family": "DejaVu Sans"}):
        figure = Figure(figsize=(6.5, 4.7), dpi=200, facecolor="white")
        FigureCanvasAgg(figure)
        axes = figure.add_axes([.19, .15, .58, .68])
        image = axes.imshow(matrix, vmin=-1, vmax=1, cmap="RdBu_r", interpolation="nearest")
        axes.set_xticks(range(6), symbols, fontsize=10)
        axes.set_yticks(range(6), symbols, fontsize=10)
        for i in range(6):
            for j in range(6):
                axes.text(j, i, f"{matrix[i, j]:.2f}", ha="center", va="center", fontsize=9.5,
                          color="white" if abs(matrix[i, j]) > .62 else "#182B38")
        colorbar = figure.colorbar(image, cax=figure.add_axes([.81, .15, .025, .68]), ticks=[-1, -.5, 0, .5, 1])
        colorbar.ax.tick_params(labelsize=9)
        colorbar.set_label("Pearson correlation", fontsize=9)
        figure.text(.12, .95, "Active strategy daily-return correlations", fontsize=12.5, weight="bold", color="#000000")
        figure.text(.12, .9, "Historical OOS 2024–2026-10-15 • 1-bp commission + 3-bp slippage", fontsize=9, color="#405263")
        figure.text(.12, .04, "Six strategy sleeves, not passive ETF returns. In-sample descriptive correlations, not forecasts.", fontsize=8, color="#475765")
        figure.savefig(target, format="png", dpi=200, facecolor="white", metadata={"Software": "Trend Following Study"})
        figure.clear()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--portfolios", type=Path, required=True)
    parser.add_argument("--correlations", type=Path, required=True)
    parser.add_argument("--input-seal", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--project-root", type=Path, default=Path.cwd())
    args = parser.parse_args(argv)
    if args.output_dir.exists():
        parser.error("output directory exists; use a new attempt")
    records = json.loads(args.manifest.read_text())["stages"]
    if set(records) != set(STAGES):
        parser.error("all three saved stages are required")
    bundles = []
    for stage in STAGES:
        path = Path(records[stage]["input"])
        bundles.append(path if path.is_absolute() else args.manifest.parent / path)
    required = [args.manifest, args.portfolios, args.correlations, *bundles]
    before = verify_seal(args.input_seal, required)  # Before any array read.
    sys.path.insert(0, str(args.project_root / "src"))
    from trend_portfolio.cli import load_portfolios
    from trend_portfolio.periods import load_stage_manifest, analyze_periods
    from trend_portfolio.plotting import prepare_plot_data
    stages = load_stage_manifest(args.manifest)
    portfolios = load_portfolios(args.portfolios, ["GDX", "FXI", "QQQ", "UNG", "FDN", "BND"])
    if tuple(item["id"] for item in portfolios) != IDS:
        raise ValueError("figures require the unchanged four-portfolio definitions in saved order")
    analyzed = analyze_periods(stages, portfolios)  # Scope/shape checks, no new engine or fit.
    args.output_dir.mkdir(parents=True, exist_ok=False)
    results = []
    for stage in stages:
        data = prepare_plot_data(stage["bundle"], portfolios,
                                 initial_timestamp=stage["initial_timestamp"], baseline_slippage=3)
        target = args.output_dir / f"{stage['id']}_baseline.png"
        render_combined(data, stage["id"], target)
        results.append({"stage": stage["id"], "file": target.name, "points_per_series": len(data.timestamps),
                        "series": len(data.labels), "initial_value": float(data.equity[0, 0]),
                        "sha256": digest(target), "all_daily_points_rendered": True,
                        "terminal_equity_by_series": dict(zip(data.series_ids, data.equity[-1].tolist())),
                        "max_daily_drawdown_by_series": dict(zip(data.series_ids, data.drawdown.min(axis=0).tolist()))})
    correlation = args.output_dir / "oos_strategy_correlations.png"
    render_correlation(args.correlations, correlation)
    after = verify_seal(args.input_seal, required)
    if before != after:
        raise ValueError("figure inputs changed during rendering")
    verification = {"baseline_commission_bps_each_way": 1, "baseline_slippage_bps_each_way": 3,
                    "raster_only": True, "daily_input_arrays_exported": False,
                    "private_input_locators_exported": False, "inputs_unchanged": True,
                    "stage_figures": results, "correlation_figure": {"file": correlation.name, "sha256": digest(correlation)},
                    "aggregate_portfolio_rows_checked": len(analyzed["portfolio_rows"])}
    (args.output_dir / "figure_verification.json").write_text(json.dumps(verification, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
