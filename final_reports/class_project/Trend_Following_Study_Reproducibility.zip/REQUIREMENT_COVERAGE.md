# Seven-section class-project coverage

The original course brief is used only as the report's organizational reference
and is not redistributed. This project adapts the research questions to actual
unlevered ETF strategy-account returns; optional course suggestions are not
represented as completed experiments.

| Course section | Completed project work and inspectable evidence | Scope or future work |
|---|---|---|
| 1. Project Goal | Compare transparent long/cash trend following and oversold/recovery mean reversion; assess cost sensitivity, growth, risk and diversification. Six fixed sleeves and four unchanged initial allocations are specified in `configs/`. | Educational retrospective research, not an investment recommendation or live deployment. |
| 2. Research Outline | Explicit indicator definitions, development/validation/historical-OOS chronology, original strict survivor selection rules and later portfolio-conditioning caveats. Four allocations are compared without new fitting. | Market-neutral pair trading, short selling, options, machine learning and unrelated strategy families are not implemented. A new prospective protocol is future work. |
| 3. Data | Existing reconciled daily/half-hour parent account studies; 1,007 / 753 / 700 daily saved valuations; separate stage clocks, controls and frozen data vintages. Public input schema and aggregate provenance are included. | Raw licensed captures, detailed reconciliation proofs and complete daily account paths stay private. The supplement does not independently rebuild source prices, missing bars or intraday trades. |
| 4. Backtesting | Daily causal indicators, seven consecutive checks over three trading hours, next eligible bar-open execution, long/cash accounts, feature-history carry only and fresh $1,000 starts are specified. The portable layer mixes saved wealth without free daily rebalancing. | Engine behavior is inherited from reviewed saved accounts; the original execution engine is not rerun or fully redistributed here. Further stress tests and new holdout periods require a separately declared study. |
| 5. Execution and Slippage | All three periods use four scenarios: 1-bp commission plus 1/3/10/25-bp one-way slippage each way. Matched passive QQQ and cash controls, distribution/reinvestment and paid terminal conventions remain embedded. | Spread/impact calibration, order-book fills, liquidity/capacity limits, taxes, fixed broker fees and live fills are not modeled by the portfolio layer. No crypto fee model is transferred. |
| 6. Weighting | Exact daily-cap, initial-only-cap, uncapped max-Sharpe and equal-initial allocations are retained. Daily capital shares drift without rebalancing; validation cap breaches remain disclosed. `cap_rows.csv` includes all 48 diagnostics. | No new optimization, risk-parity, dynamic rebalancing, leverage, cash reuse between sleeves or future-cap enforcement. The standalone maximum-CAGR GDX case is excluded. |
| 7. Performance Evaluation | All 48 portfolio stage/cost outcomes; matched controls; Sharpe, actual-clock CAGR, daily drawdown, volatility and terminal wealth; four raster figures; 48 single-factor and 48 joint-factor attribution fits, diagnostics and synthetic/control checks. | Alpha is descriptive, not skill. Serial-correlation-robust inference, bootstrap confidence intervals, deflated Sharpe, PBO/CSCV, prospective testing and live monitoring remain future work. |

## Completed versus proposed

Completed results appear in the CSV/JSON and figures. Research extensions above
are proposals only. There are no invented author details, course identifiers,
new account runs, new weight fits or claims that every optional prompt in the
course brief has been implemented. The project is complete within its declared
ETF long/cash comparison scope, with reproducibility limits stated explicitly.
